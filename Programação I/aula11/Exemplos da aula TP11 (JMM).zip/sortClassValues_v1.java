public class sortClassValues_v1 {
	public static void main(String [] args) {
		Aluno [] s = {	new Aluno (11000, "Pedro"  , 15),
						new Aluno (20000, "Maria"  , 18),
						new Aluno (33100, "Ana"    ,  8),
						new Aluno (45000, "Miguel" , 14),
						new Aluno (50000, "Joana"  , 16),
						new Aluno (66000, "Anabela", 15)};
		OrdenacaoFlutuacao(s, s.length);
		for(int i=0; i < s.length; i++)
			System.out.println( s[i].nmec + ", " + 
								s[i].nome + ", " +
								s[i].nota);
	}
	
	public static void OrdenacaoFlutuacao(Aluno [] seq, int n){
		Aluno tmp;
		int i, j;
		boolean trocas;
		do{
			trocas = false; // partimos do principio que já está...
			for(i = 0 ; i < n -1 ; i++){
//			if(seq[i].nome.compareTo(seq[i+1].nome) > 0){
//			if(seq[i].nmec > seq[i+1].nmec){
			if(seq[i].nota < seq[i+1].nota){
				tmp = seq[i];
				seq[i] = seq[i+1];
				seq[i+1] = tmp;
				trocas = true; // houve trocas...
				}
			}
		}while(trocas); // enquanto houver trocas repetimos
	}
}
class Aluno {
	int nmec, nota;
	String nome;
	
	public Aluno(int nmec, String nome, int nota) {
		this.nmec = nmec;
		this.nome = nome;
		this.nota = nota;
	}
	
	public String toString() {
		return 	this.nmec + ", " + 
				this.nome + ", " +
				this.nota;
	}
}
