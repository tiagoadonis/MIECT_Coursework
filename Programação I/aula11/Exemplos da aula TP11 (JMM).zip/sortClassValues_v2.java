public class sortClassValues_v2 {
	public static void main(String [] args) {
		Aluno [] s = new Aluno [5];
		s[0] = new Aluno();
		s[0].nmec = 20000;		s[0].nome = "Maria";		s[0].nota = 18;
		s[1] = new Aluno();
		s[1].nmec = 33100;		s[1].nome = "Ana";  		s[1].nota = 8;
		s[2] = new Aluno();
		s[2].nmec = 45000;		s[2].nome = "Miguel";		s[2].nota = 14;
		s[3] = new Aluno();
		s[3].nmec = 50000;		s[3].nome = "Joana";		s[3].nota = 16;
		s[4] = new Aluno();
		s[4].nmec = 66000;		s[4].nome = "Anabela";		s[4].nota = 15;
		
		OrdenacaoFlutuacao(s, s.length);
		for(int i=0; i < s.length; i++)
			System.out.println( s[i].nmec + ", " + 
								s[i].nome + ", " +
								s[i].nota);
	}
	
	public static void OrdenacaoFlutuacao(Aluno [] seq, int n){
		Aluno tmp;
		int i, j;
		boolean trocas;
		do{
			trocas = false; // partimos do principio que já está...
			for(i = 0 ; i < n -1 ; i++){
//			if(seq[i].nome.compareTo(seq[i+1].nome) > 0){
//			if(seq[i].nmec > seq[i+1].nmec){
			if(seq[i].nota < seq[i+1].nota){
				tmp = seq[i];
				seq[i] = seq[i+1];
				seq[i+1] = tmp;
				trocas = true; // houve trocas...
				}
			}
		}while(trocas); // enquanto houver trocas repetimos
	}
}
class Aluno {
	int nmec, nota;
	String nome;
}
