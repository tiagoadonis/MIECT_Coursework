public class sortInts {
	public static void main(String [] args) {
		int [] s = {3, 5, 9, 2, 6};
		OrdenacaoFlutuacao(s, s.length);
		for(int i=0; i < s.length; i++)
			System.out.println(s[i]);
	}
	
	public static void OrdenacaoFlutuacao(int[] seq, int n){
		int tmp;
		int i, j;
		boolean trocas;
		do{
			trocas = false; // partimos do principio que já está...
			for(i = 0 ; i < n -1 ; i++){
			if(seq[i] > seq[i+1]){
				tmp = seq[i];
				seq[i] = seq[i+1];
				seq[i+1] = tmp;
				trocas = true; // houve trocas...
				}
			}
		}while(trocas); // enquanto houver trocas repetimos
	}
}
