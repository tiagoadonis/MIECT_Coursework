// ler e escrever uma matriz
import java.util.*;
public class arrays2D_v2 {
	static Scanner sc = new Scanner(System.in);
	public static void main(String [] args) {
		int [][] mat = new int[3][2];
		lerMatriz(mat);
		mostrarMatriz(mat);
	}
	
	static void lerMatriz(int [][] m) {
		for(int i=0; i<m.length; i++) {
			for(int j=0; j<m[0].length; j++) {
				//System.out.printf("Valor (%d,%d): ", i+1, j+1);
				//m[i][j] = sc.nextInt();
				m[i][j] = (int) (Math.random()*10);
			}
		}
	}
	
	static void mostrarMatriz(int [][] m) {
		for(int i=0; i<m.length; i++) {
			for(int j=0; j<m[i].length; j++) {
				System.out.printf("%4d", m[i][j]);
			}
			System.out.println();
		}
	}
}
