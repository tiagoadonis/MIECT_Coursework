/* Este programa gera uma chave (5 numeros entre 1 e 50 e duas estrelas entre
 * 1 e 9) para um concurso do euromilh�es e mostra a chave ordenada no ecr�.
 * De seguida, o programa l� um ficheiro de apostas (cada linha corresponde a
 * uma aposta: 5 numeros + 2 estrelas) e armazena as apostas num array 
 * multidimensional com 7 colunas. O n�mero de linhas � igual ao n�mero de 
 * apostas no ficheiro.
 * No final, apresenta os resultados no ecr� no seguinte formato:
 * 
  		Chave:  8 10 38 41 49 +  6  7
		Apostas:
		1:  5  9 12 22 41 +  1  3 (1,0)
		2:  2  4  6  8 10 +  2  4 (2,0)
		3:  5 10 20 30 40 +  7  9 (1,1)
		O n�mero de totalistas foi 0
 * 
 * O para de valores entre parentesis representa o apuramento do resultado,
 * i.e., numeros certos e estrelas certas.
 *  
 * */

import java.util.Scanner;
import java.io.*;
public class Apostas {
	static Scanner sc = new Scanner(System.in);
	public static void main(String [] args) throws IOException {
		int [] chave = new int[7];
		int [][] apostas;
		int totalistas;
		
		sortearChave(chave, 0, 5, 50);
		sortearChave(chave, 5, 7, 9);
		ordenar(chave, 0, 5);
		ordenar(chave, 5, 7);		

		System.out.print("Chave:");
		imprimir(chave);
		System.out.println();

		apostas = lerApostas("apostas.txt");
		totalistas = apurarResultado(chave, apostas);
		System.out.printf("O n�mero de totalistas foi %d\n", totalistas);
	}
	
	static void sortearChave(int [] chave, int primeiro, int ultimo, int N) {
		int i;
		for(i=primeiro; i<ultimo; i++) {
			chave[i] = 1 + (int)(Math.random()*N);
			while(validarChave(chave, i)==false)
				chave[i] = 1 + (int)(Math.random()*N);
		}
	}
	
	static boolean validarChave(int [] chave, int ultimo) {
		int j;
		for(j=0; j<ultimo; j++)
			if(chave[j] == chave[ultimo])
				return false;
		return true;
	}
	
	static void imprimir(int [] chave) {
		int i;
		for(i=0; i<5;i++)
			System.out.printf("%3d", chave[i]);
		System.out.print(" +");
		for(i=5; i<7;i++)
			System.out.printf("%3d", chave[i]);		
	}
	
	static int[][] lerApostas(String nomeFicheiro) throws IOException{
		int n, i;
		
		int nApostas = contarLinhas(nomeFicheiro);
		int [][] apostas = new int [nApostas][7];
		
		File f = new File(nomeFicheiro);
		if(f.exists() && f.isFile() && f.canRead()) {
			Scanner scf = new Scanner(f);
			n=0;
			while(scf.hasNextLine()) {
				for(i=0; i<7; i++)
					apostas[n][i] = scf.nextInt();
				n++;
			}
			scf.close();
		}
		return apostas;
	}
	
	static int contarLinhas(String nomeFicheiro) throws IOException{
		File f = new File(nomeFicheiro);
		int n=0;
		if(f.exists() && f.isFile() && f.canRead()) {
			Scanner scf = new Scanner(f);
			while(scf.hasNextLine()) {
				n++;
				scf.nextLine();
			}
			scf.close();
		}
		return n;
	}
	
	static int apurarResultado(int [] chave, int [] [] apostas) {
		int totalistas = 0, i, j, numeros, estrelas;

		System.out.println("Apostas:");
		for(i=0; i<apostas.length; i++) {
			
			ordenar(apostas[i], 0, 5);
			ordenar(apostas[i], 5, 7);
			numeros = 0;
			
			for(j=0; j<5; j++)
				if(acertou(apostas[i][j], chave, 0, 5))
					numeros++;
			
			estrelas=0;
			for(j=5; j<7; j++)
				if(acertou(apostas[i][j], chave, 5, 7))
					estrelas++;
			
			System.out.printf("%5d:", i+1);
			imprimir(apostas[i]);
			System.out.printf(" (%d,%d)\n", numeros, estrelas);
			
			if(numeros==5 && estrelas==2)
				totalistas++;
		}
		return totalistas;
	}
	
	static void ordenar(int [] s, int inicio, int fim) {
		int i, j, tmp;
		for(i=inicio; i<fim-1; i++)
			for(j=i+1; j<fim; j++)
				if(s[i] > s[j]) {
					tmp = s[i];
					s[i] = s[j];
					s[j] = tmp;
				}
	}
	
	static boolean acertou(int numero, int [] chave, int inicio, int fim) {
		while(inicio < fim && numero > chave[inicio])
			inicio++;
		if(inicio == fim) return false;
		else if (numero == chave[inicio]) return true;
		else return false;
	}
}
