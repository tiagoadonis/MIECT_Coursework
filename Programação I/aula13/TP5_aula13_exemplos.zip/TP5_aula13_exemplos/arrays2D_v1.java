// ler e escrever uma matriz
import java.util.*;
public class arrays2D_v1 {
	static Scanner sc = new Scanner(System.in);
	public static void main(String [] args) {
		int mat [][];
		mat = lerMatriz(3, 2);
		mostrarMatriz(mat);
	}
	
	static int [][] lerMatriz(int lin, int col) {
		int [][] m = new int[lin][col];
		for(int i=0; i<lin; i++) {
			for(int j=0; j<col; j++) {
				//System.out.printf("Valor (%d,%d): ", i+1, j+1);
				//m[i][j] = sc.nextInt();
				m[i][j] = (int) (Math.random()*10);
			}
		}
		return m;
	}
	
	static void mostrarMatriz(int [][] m) {
		for(int i=0; i<m.length; i++) {
			for(int j=0; j<m[i].length; j++) {
				System.out.printf("%4d", m[i][j]);
			}
			System.out.println();
		}
	}
}
